// 公众号：茗阁  获取最新更新源码
// 
require('./common/runtime.js')
require('./common/vendor.js')
require('./common/main.js')